import * as THREE from 'three';
import './style.css';

const $ = (id) => document.getElementById(id);
const mount = $('game');
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x9bb4c2);
scene.fog = new THREE.Fog(0x9bb4c2, 55, 185);

const camera = new THREE.PerspectiveCamera(62, innerWidth / innerHeight, 0.1, 260);
camera.position.set(0, 6, 11);

const renderer = new THREE.WebGLRenderer({
  antialias: innerWidth > 700,
  powerPreference: 'high-performance'
});
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
renderer.setSize(innerWidth, innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.12;
renderer.shadowMap.enabled = innerWidth > 700;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
mount.appendChild(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xdceeff, 0x45515a, 2.0));
const sun = new THREE.DirectionalLight(0xffe4bd, 2.1);
sun.position.set(-35, 55, 25);
sun.castShadow = renderer.shadowMap.enabled;
sun.shadow.mapSize.set(1024, 1024);
sun.shadow.camera.left = -65; sun.shadow.camera.right = 65;
sun.shadow.camera.top = 65; sun.shadow.camera.bottom = -65;
scene.add(sun);

const mat = (color, roughness = 0.82, metalness = 0) =>
  new THREE.MeshStandardMaterial({ color, roughness, metalness });
const mats = {
  ground: mat(0x53675e), road: mat(0x252d34), sidewalk: mat(0x9aa1a0),
  line: mat(0xe0d2a7), skin: mat(0xc68e68), shirt: mat(0x243b50),
  pants: mat(0x202832), tire: mat(0x101317), glass: new THREE.MeshStandardMaterial({color:0x8db3c4,roughness:.22,metalness:.25}),
  police: mat(0xd9e0e4,.45,.18), black: mat(0x151c23,.45,.25)
};
const buildingMats = [0x667783,0x9a8d7c,0x59656b,0xb0a18b,0x667064,0x788b91].map(c=>mat(c));
const windowMat = new THREE.MeshStandardMaterial({color:0x9ed3e6,emissive:0x294b5a,roughness:.28,metalness:.18});

function box(w,h,d,material,x,y,z,cast=true) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w,h,d), material);
  mesh.position.set(x,y,z);
  mesh.castShadow = cast; mesh.receiveShadow = true;
  scene.add(mesh); return mesh;
}
function cylinder(r1,r2,h,material,x,y,z,segments=12) {
  const mesh = new THREE.Mesh(new THREE.CylinderGeometry(r1,r2,h,segments),material);
  mesh.position.set(x,y,z); mesh.castShadow=true; scene.add(mesh); return mesh;
}

// Ground and a compact city grid.
const ground = new THREE.Mesh(new THREE.PlaneGeometry(230,230),mats.ground);
ground.rotation.x=-Math.PI/2; ground.receiveShadow=true; scene.add(ground);
for(let i=-2;i<=2;i++){
  const p=i*28;
  box(11,.08,230,mats.road,p,.04,0,false);
  box(230,.08,11,mats.road,0,.045,p,false);
  box(1,.12,230,mats.sidewalk,p-6,.06,0,false);
  box(1,.12,230,mats.sidewalk,p+6,.06,0,false);
  box(230,.12,1,mats.sidewalk,0,.06,p-6,false);
  box(230,.12,1,mats.sidewalk,0,.06,p+6,false);
}
for(let p=-105;p<=105;p+=9){
  box(.13,.025,3,mats.line,0,.105,p,false);
  box(3,.025,.13,mats.line,p,.105,0,false);
}
const obstacles=[];
for(let gx=-2;gx<=2;gx++) for(let gz=-2;gz<=2;gz++){
  if(gx===0 || gz===0) continue;
  for(let n=0;n<3;n++){
    const x=gx*28+(n-1)*6.5;
    const z=gz*28+(n%2?7:-7);
    const h=9+((Math.abs(gx*7+gz*11+n*13)%14));
    const width=4.8, depth=6.2;
    const b=box(width,h,depth,buildingMats[(Math.abs(gx+gz+n))%buildingMats.length],x,h/2,z);
    obstacles.push({x,z,halfW:width/2+.8,halfD:depth/2+.8});
    // simple front-facing window bands
    for(let floor=1;floor<Math.floor(h/3);floor++){
      box(2.7,.8,.05,windowMat,x,h/2-h/2+floor*2.7,z-depth/2-.035,false);
    }
  }
}
// Store with a visible sign: the robbery target.
const store = new THREE.Group(); scene.add(store);
const storeBase = new THREE.Mesh(new THREE.BoxGeometry(7,4.5,5),mat(0x7a5b43));
storeBase.position.y=2.25; storeBase.castShadow=true; store.add(storeBase);
const storeGlass = new THREE.Mesh(new THREE.BoxGeometry(5.5,2.2,.08),mats.glass);
storeGlass.position.set(0,1.7,-2.54); store.add(storeGlass);
const sign = new THREE.Mesh(new THREE.BoxGeometry(5.5,.65,.22),mat(0xe9a73c));
sign.position.set(0,4.0,-2.55); store.add(sign);
store.position.set(15,0,-15);
const signText = document.createElement('div');
signText.textContent='MARKET';
signText.style.cssText='position:fixed;left:-9999px';
document.body.appendChild(signText);

// Player model.
const player = new THREE.Group(); scene.add(player);
const torso = new THREE.Mesh(new THREE.CapsuleGeometry(.48,.85,4,8),mats.shirt);
torso.position.y=1.35; torso.castShadow=true; player.add(torso);
const head = new THREE.Mesh(new THREE.SphereGeometry(.32,12,10),mats.skin);
head.position.y=2.12; head.castShadow=true; player.add(head);
const legMat=mats.pants;
for(const x of [-.2,.2]){
  const leg=new THREE.Mesh(new THREE.CapsuleGeometry(.17,.65,3,6),legMat);
  leg.position.set(x,.48,0); leg.castShadow=true; player.add(leg);
}
player.position.set(0,0,8);

// Cars are built from simple meshes to keep the prototype light.
function makeCar(color=0x31566d, police=false){
  const car=new THREE.Group();
  const body=new THREE.Mesh(new THREE.BoxGeometry(2.05,.72,4.0),mat(color,.42,.22));
  body.position.y=.75; body.castShadow=true; car.add(body);
  const cabin=new THREE.Mesh(new THREE.BoxGeometry(1.55,.72,1.9),police?mats.glass:mats.glass);
  cabin.position.set(0,1.35,-.25); cabin.castShadow=true; car.add(cabin);
  for(const x of [-.94,.94]) for(const z of [-1.25,1.25]){
    const wheel=new THREE.Mesh(new THREE.CylinderGeometry(.38,.38,.22,12),mats.tire);
    wheel.rotation.z=Math.PI/2; wheel.position.set(x,.4,z); car.add(wheel);
  }
  if(police){
    const red=new THREE.Mesh(new THREE.BoxGeometry(.48,.15,.24),mat(0xff263b,.3));
    red.position.set(-.28,1.77,-.25); car.add(red);
    const blue=new THREE.Mesh(new THREE.BoxGeometry(.48,.15,.24),mat(0x247cff,.3));
    blue.position.set(.28,1.77,-.25); car.add(blue);
  }
  scene.add(car); return car;
}
const playerCar=makeCar(0x294c63,false);
playerCar.position.set(0,0,1);
playerCar.rotation.y=Math.PI;
let inCar=false, carSpeed=0;
const policeCar=makeCar(0xe2e6e8,true);
policeCar.position.set(-35,0,-35);
policeCar.visible=false;
let policeActive=false;

// Mission marker.
const marker=new THREE.Mesh(new THREE.TorusGeometry(2.1,.16,8,28),new THREE.MeshBasicMaterial({color:0xffc45d}));
marker.rotation.x=Math.PI/2; marker.position.set(15,.25,-15); scene.add(marker);
const markerBeam=new THREE.Mesh(new THREE.CylinderGeometry(.08,.55,4,12,1,true),new THREE.MeshBasicMaterial({color:0xffc45d,transparent:true,opacity:.16,side:THREE.DoubleSide}));
markerBeam.position.set(15,2,-15); scene.add(markerBeam);

// Input state and touch joystick.
const input={x:0,y:0};
const joystick=$('joystick'), knob=$('stickKnob');
let joyPointer=null;
function setJoystick(e){
  const r=joystick.getBoundingClientRect();
  const cx=r.left+r.width/2, cy=r.top+r.height/2;
  let dx=e.clientX-cx, dy=e.clientY-cy;
  const max=35, len=Math.hypot(dx,dy)||1;
  if(len>max){dx=dx/len*max;dy=dy/len*max;}
  input.x=dx/max; input.y=-dy/max;
  knob.style.transform=`translate(${dx}px,${dy}px)`;
}
joystick.addEventListener('pointerdown',e=>{joyPointer=e.pointerId;joystick.setPointerCapture(e.pointerId);setJoystick(e);});
joystick.addEventListener('pointermove',e=>{if(e.pointerId===joyPointer)setJoystick(e);});
function releaseJoy(e){if(e.pointerId===joyPointer){joyPointer=null;input.x=0;input.y=0;knob.style.transform='translate(0,0)';}}
joystick.addEventListener('pointerup',releaseJoy); joystick.addEventListener('pointercancel',releaseJoy);

// Swipe on the open screen to rotate the camera.
let dragPointer=null,lastX=0;
let cameraYaw=0.15;
renderer.domElement.addEventListener('pointerdown',e=>{dragPointer=e.pointerId;lastX=e.clientX;});
renderer.domElement.addEventListener('pointermove',e=>{
  if(dragPointer===e.pointerId){const dx=e.clientX-lastX;cameraYaw-=dx*.006;lastX=e.clientX;}
});
function endDrag(e){if(dragPointer===e.pointerId)dragPointer=null;}
renderer.domElement.addEventListener('pointerup',endDrag);
renderer.domElement.addEventListener('pointercancel',endDrag);

let cash=0, wanted=0, toastTimer;
function toast(message){
  const el=$('toast'); el.textContent=message; el.classList.add('show');
  clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove('show'),1900);
}
function setWanted(level){
  wanted=Math.max(0,Math.min(5,level));
  $('stars').textContent='★'.repeat(wanted)+'☆'.repeat(5-wanted);
  if(wanted>0 && !policeActive){
    policeActive=true; policeCar.visible=true;
    policeCar.position.set(player.position.x-28,0,player.position.z-24);
    toast('الشرطة في طريقها إليك!');
  }
  if(wanted===0){policeActive=false;policeCar.visible=false;}
}
function updateHud(){
  $('cash').textContent=cash.toLocaleString('en-US');
  $('missionText').textContent=wanted?'اهرب من الشرطة وابتعد عن منطقة البحث':'اقترب من المتجر لبدء السرقة';
}
function near(a,b,d){return a.position.distanceTo(b.position)<d;}

$('actionBtn').addEventListener('click',()=>{
  if(inCar){
    toast('أنت داخل السيارة. اضغط قيادة للخروج.');
    return;
  }
  if(player.position.distanceTo(store.position)<9 && wanted===0){
    cash+=250; setWanted(2); toast('نجحت السرقة! حصلت على $250');
    $('missionTag').textContent='المهمة 02';
  }else if(player.position.distanceTo(playerCar.position)<5){
    inCar=true; player.visible=false; playerCar.visible=true; toast('ركبت السيارة. قد الآن!');
  }else{
    toast('اقترب من المتجر أو سيارتك للتفاعل');
  }
  updateHud();
});
$('driveBtn').addEventListener('click',()=>{
  if(inCar){inCar=false;player.visible=true;player.position.copy(playerCar.position);player.position.x+=2.5;toast('خرجت من السيارة');}
  else if(player.position.distanceTo(playerCar.position)<5){inCar=true;player.visible=false;toast('أنت تقود الآن');}
  else toast('اقترب من السيارة أولاً');
});

const clock=new THREE.Clock();
const desiredCam=new THREE.Vector3();
const lookTarget=new THREE.Vector3();
const forward=new THREE.Vector3();
const right=new THREE.Vector3();
function blocked(x,z){
  if(Math.abs(x)>108||Math.abs(z)>108)return true;
  return obstacles.some(o=>Math.abs(x-o.x)<o.halfW && Math.abs(z-o.z)<o.halfD);
}
function updatePlayer(dt){
  const speed=inCar?0:6.2;
  const mag=Math.hypot(input.x,input.y);
  if(mag>.08){
    const angle=cameraYaw;
    forward.set(-Math.sin(angle),0,-Math.cos(angle));
    right.set(Math.cos(angle),0,-Math.sin(angle));
    const moveX=(forward.x*input.y+right.x*input.x);
    const moveZ=(forward.z*input.y+right.z*input.x);
    const len=Math.hypot(moveX,moveZ)||1;
    const nx=player.position.x+moveX/len*speed*dt;
    const nz=player.position.z+moveZ/len*speed*dt;
    if(!blocked(nx,player.position.z))player.position.x=nx;
    if(!blocked(player.position.x,nz))player.position.z=nz;
    player.rotation.y=Math.atan2(moveX,moveZ);
  }
  if(inCar){
    const throttle=input.y;
    carSpeed=THREE.MathUtils.damp(carSpeed,throttle*19,2.2,dt);
    playerCar.rotation.y+=input.x*dt*(carSpeed>=0?1:-1)*1.45;
    const dir=new THREE.Vector3(Math.sin(playerCar.rotation.y),0,Math.cos(playerCar.rotation.y));
    const nx=playerCar.position.x+dir.x*carSpeed*dt;
    const nz=playerCar.position.z+dir.z*carSpeed*dt;
    if(!blocked(nx,nz)){playerCar.position.x=nx;playerCar.position.z=nz;}else carSpeed=0;
    playerCar.position.y=0;
  }
}
function updatePolice(dt){
  if(!policeActive)return;
  const target=inCar?playerCar.position:player.position;
  const dx=target.x-policeCar.position.x,dz=target.z-policeCar.position.z;
  const dist=Math.hypot(dx,dz);
  if(dist>1.8){
    const angle=Math.atan2(dx,dz);
    const angleDiff = THREE.MathUtils.euclideanModulo(angle - policeCar.rotation.y + Math.PI, Math.PI * 2) - Math.PI;
    policeCar.rotation.y += angleDiff * (1 - Math.exp(-3.0 * dt));
    const step=Math.min(9*dt,dist);
    policeCar.position.x+=Math.sin(policeCar.rotation.y)*step;
    policeCar.position.z+=Math.cos(policeCar.rotation.y)*step;
  }
  if(dist<5){
    toast('الشرطة قبضت عليك! تمت إعادة المحاولة');
    cash=Math.max(0,cash-100); setWanted(0);
    player.position.set(0,0,8); playerCar.position.set(0,0,1); inCar=false; player.visible=true;
    updateHud();
  }
}
function updateCamera(dt){
  const target=inCar?playerCar.position:player.position;
  const distance=inCar?10:8.5;
  desiredCam.set(
    target.x+Math.sin(cameraYaw)*distance,
    target.y+(inCar?5.2:5.8),
    target.z+Math.cos(cameraYaw)*distance
  );
  camera.position.lerp(desiredCam,1-Math.exp(-5*dt));
  lookTarget.set(target.x,target.y+1.2,target.z);
  camera.lookAt(lookTarget);
}
function animate(){
  requestAnimationFrame(animate);
  const dt=Math.min(clock.getDelta(),.04);
  marker.rotation.z+=dt*.7;
  markerBeam.material.opacity=.12+Math.sin(performance.now()*.002)*.05;
  updatePlayer(dt); updatePolice(dt); updateCamera(dt); updateHud();
  renderer.render(scene,camera);
}
animate();

addEventListener('resize',()=>{
  camera.aspect=innerWidth/innerHeight; camera.updateProjectionMatrix();
  renderer.setPixelRatio(Math.min(devicePixelRatio||1,1.5));
  renderer.setSize(innerWidth,innerHeight);
});
document.addEventListener('visibilitychange',()=>{if(document.hidden){input.x=0;input.y=0;}});

// Keyboard controls for desktop testing too.
const keys={};
addEventListener('keydown',e=>{keys[e.key.toLowerCase()]=true;});
addEventListener('keyup',e=>{keys[e.key.toLowerCase()]=false;});
function keyboardLoop(){
  if(keys.w||keys.arrowup)input.y=1;
  else if(keys.s||keys.arrowdown)input.y=-1;
  if(keys.a||keys.arrowleft)input.x=-1;
  else if(keys.d||keys.arrowright)input.x=1;
  if(!['w','arrowup','s','arrowdown'].some(k=>keys[k]) && joyPointer===null)input.y=0;
  if(!['a','arrowleft','d','arrowright'].some(k=>keys[k]) && joyPointer===null)input.x=0;
  requestAnimationFrame(keyboardLoop);
}
keyboardLoop();

if('serviceWorker' in navigator){
  window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
}
